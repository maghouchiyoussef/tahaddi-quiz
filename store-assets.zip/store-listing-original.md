# تحدي — كل معلومات Google Play Console

## معلومات أساسية
- App or game: **Game**
- App name (AR): تحدي - مسابقة الثقافة الإسلامية
- App name (EN): Tahaddi - Islamic Quiz
- Package ID: com.tahaddi.quiz
- Category: Games > Trivia
- Free, No ads, No Advertising ID
- Target audience: 13-15, 16-17, 18+
- Contact email: devfoxmy@gmail.com
- Privacy Policy URL: https://claude.ai/artifact/BV6yb6kKDDWKSNk7fZcocg

## أجوبة الاستبيانات
- Sign in details: No
- Ads: No
- Advertising ID: No
- Content rating: Category = Game → No على كل الأسئلة (بلا عنف، بلا مقامرة، بلا تفاعل بين المستخدمين، بلا مشتريات)
- Data safety: لا يجمع ولا يشارك أي بيانات
- Government / Financial / Health: No على الكل

## Short description (AR)
اختبر معلوماتك فـ القرآن والسيرة والصحابة والتاريخ الإسلامي، بدون إنترنت

## Full description (AR)
تحدي — مسابقة الثقافة الإسلامية

🎯 114 سؤال موزعة على 6 فئات:
📖 القرآن الكريم
🕌 السيرة النبوية
⭐ الصحابة الكرام
🤲 الفقه والعبادات
🏛️ التاريخ الإسلامي
💡 ثقافة عامة

⏱️ كيف تلعب؟
اختر فئة أو العب بأسئلة عشوائية. 10 أسئلة فـ كل جولة، و15 ثانية لكل سؤال.

✨ المزايا:
• شرح تعليمي بعد كل سؤال — تتعلم وأنت تلعب
• نظام نقاط مع مكافأة للإجابات الصحيحة المتتالية
• أفضل نتيجة محفوظة لكل فئة
• ترتيب الأسئلة والخيارات يتغير فـ كل جولة
• يعمل بالكامل بدون إنترنت
• بدون حساب، بدون تتبع، بدون جمع أي بيانات

مناسبة للعائلة، للمسابقات فـ رمضان، وللطلاب والمهتمين بالثقافة الإسلامية.

## Short description (EN)
Test your knowledge of the Quran, Seerah, Sahaba and Islamic history. Offline.

## Full description (EN)
Tahaddi — the Islamic culture quiz

🎯 114 questions across 6 categories: Quran, Seerah, Sahaba, Fiqh & worship, Islamic history, and general knowledge.

⏱️ 10 questions per round, 15 seconds each. Pick a category or play a random mix.

✨ Features:
• A short explanation after every question — learn as you play
• Points system with streak bonuses
• Best score saved for each category
• Questions and answers shuffle every round
• Works fully offline
• No account, no tracking, no data collection

Great for families, Ramadan quiz nights, students, and anyone curious about Islamic culture.

## Release notes (AR)
الإصدار الأول من تحدي — 114 سؤال فـ 6 فئات

## AI asset declaration
- علّم فقط: App icon + Feature graphic
- السكرين شوتات: لا
