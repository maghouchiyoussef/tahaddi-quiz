package com.tahaddi.quiz;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
