package com.devfoxmy.tahaddi;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
