// طبقة الإعلانات (AdMob). على الويب كتولي بلا مفعول.
(function(){
  'use strict';
  const N = window.Native;
  const C = window.ADS_CONFIG || {};
  const native = !!(N && N.isNative);

  let ready = false;
  let bannerShown = false;
  let bannerWanted = false;
  let interstitialLoaded = false;
  let rewardedLoaded = false;
  let privacyRequired = false;
  let roundsSinceInterstitial = 0;

  function setBannerSpace(px){
    document.documentElement.style.setProperty('--banner-h', (px || 0) + 'px');
  }

  async function init(){
    if(!native) return;
    const A = N.AdMob;
    try{
      await A.initialize({ initializeForTesting: !!C.TEST_MODE });
      // موافقة المستخدم (GDPR / UMP)
      try{
        let info = await A.requestConsentInfo();
        if(info.isConsentFormAvailable && info.status === 'REQUIRED'){
          info = await A.showConsentForm();
        }
        privacyRequired = info.privacyOptionsRequirementStatus === 'REQUIRED';
        if(info.canRequestAds === false){ return; }
      }catch(e){ /* نكملو حتى إلا فشلات الموافقة */ }

      A.addListener(N.BannerAdPluginEvents.SizeChanged, (s) => setBannerSpace(s && s.height));
      A.addListener(N.BannerAdPluginEvents.FailedToLoad, () => setBannerSpace(0));
      A.addListener(N.InterstitialAdPluginEvents.Dismissed, () => { interstitialLoaded = false; loadInterstitial(); });
      A.addListener(N.InterstitialAdPluginEvents.FailedToLoad, () => { interstitialLoaded = false; });
      A.addListener(N.RewardAdPluginEvents.FailedToLoad, () => { rewardedLoaded = false; });

      ready = true;
      loadInterstitial();
      loadRewarded();
      if(bannerWanted) showBanner();
      document.dispatchEvent(new CustomEvent('ads-ready'));
    }catch(e){ ready = false; }
  }

  async function loadInterstitial(){
    if(!ready) return;
    try{ await N.AdMob.prepareInterstitial({ adId: C.INTERSTITIAL_ID, isTesting: !!C.TEST_MODE }); interstitialLoaded = true; }
    catch(e){ interstitialLoaded = false; }
  }
  async function loadRewarded(){
    if(!ready) return;
    try{ await N.AdMob.prepareRewardVideoAd({ adId: C.REWARDED_ID, isTesting: !!C.TEST_MODE }); rewardedLoaded = true; }
    catch(e){ rewardedLoaded = false; }
  }

  async function showBanner(){
    bannerWanted = true;
    if(!ready) return;
    try{
      if(bannerShown){ await N.AdMob.resumeBanner(); return; }
      await N.AdMob.showBanner({
        adId: C.BANNER_ID, adSize: N.BannerAdSize.ADAPTIVE_BANNER,
        position: N.BannerAdPosition.BOTTOM_CENTER, margin: 0, isTesting: !!C.TEST_MODE,
      });
      bannerShown = true;
    }catch(e){}
  }
  async function hideBanner(){
    bannerWanted = false;
    setBannerSpace(0);
    if(!ready || !bannerShown) return;
    try{ await N.AdMob.hideBanner(); }catch(e){}
  }

  // كيتعيط عليها من بعد كل جولة كاملة
  async function maybeInterstitial(){
    roundsSinceInterstitial++;
    if(!ready || !interstitialLoaded) return;
    if(roundsSinceInterstitial < (C.INTERSTITIAL_EVERY_N_ROUNDS || 2)) return;
    roundsSinceInterstitial = 0;
    try{ await N.AdMob.showInterstitial(); }catch(e){ loadInterstitial(); }
  }

  function rewardedAvailable(){ return ready && rewardedLoaded; }

  // كترجع true إلا المستخدم خذا المكافأة
  function showRewarded(){
    return new Promise(async (resolve) => {
      if(!rewardedAvailable()){ resolve(false); return; }
      let rewarded = false, done = false;
      const A = N.AdMob;
      const h1 = await A.addListener(N.RewardAdPluginEvents.Rewarded, () => { rewarded = true; });
      const h2 = await A.addListener(N.RewardAdPluginEvents.Dismissed, finish);
      const h3 = await A.addListener(N.RewardAdPluginEvents.FailedToShow, finish);
      function finish(){
        if(done) return; done = true;
        [h1,h2,h3].forEach(h => { try{ h.remove(); }catch(e){} });
        rewardedLoaded = false; loadRewarded();
        resolve(rewarded);
      }
      try{ await A.showRewardVideoAd(); rewarded = true; }catch(e){ finish(); }
    });
  }

  async function showPrivacyOptions(){
    if(!ready) return;
    try{ await N.AdMob.showPrivacyOptionsForm(); }catch(e){}
  }

  window.Ads = {
    init, showBanner, hideBanner, maybeInterstitial, rewardedAvailable, showRewarded, showPrivacyOptions,
    get isNative(){ return native; },
    get privacyRequired(){ return privacyRequired; },
  };
})();
