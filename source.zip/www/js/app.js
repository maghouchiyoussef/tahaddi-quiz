(function(){
  'use strict';

  const QUESTIONS_PER_ROUND = 10;
  const TIME_PER_QUESTION = 15;
  const LOW_TIME = 5;

  const $ = (id) => document.getElementById(id);
  const els = {
    screenHome: $('screen-home'), screenQuiz: $('screen-quiz'), screenResult: $('screen-result'),
    totalBest: $('total-best'), totalStars: $('total-stars'), totalPlayed: $('total-played'),
    catGrid: $('cat-grid'), randomPlayBtn: $('random-play-btn'),
    quizBackBtn: $('quiz-back-btn'), quizCatTitle: $('quiz-cat-title'), timerNum: $('timer-num'),
    quizProgress: $('quiz-progress'), quizScore: $('quiz-score'), quizStreak: $('quiz-streak'),
    timerBarFill: $('timer-bar-fill'), questionText: $('question-text'), optionsList: $('options-list'),
    explainBox: $('explain-box'), nextBtn: $('next-btn'),
    llFifty: $('ll-fifty'), llFiftyBadge: $('ll-fifty-badge'), llSkip: $('ll-skip'), llSkipBadge: $('ll-skip-badge'),
    resultEmoji: $('result-emoji'), resultStars: $('result-stars'), resultTitle: $('result-title'),
    resultScore: $('result-score'), resultTotal: $('result-total'), resultPoints: $('result-points'),
    newBest: $('new-best'), doubleBtn: $('double-btn'), playAgainBtn: $('play-again-btn'), backHomeBtn: $('back-home-btn'),
    settingsBtn: $('settings-btn'), sheet: $('sheet'), sheetBg: $('sheet-bg'),
    swSound: $('sw-sound'), swVibrate: $('sw-vibrate'), rowPrivacy: $('row-privacy-options'),
    privacyOptionsBtn: $('privacy-options-btn'), resetBtn: $('reset-btn'), toast: $('toast'),
  };

  const game = {
    categoryId: null, roundQuestions: [], reserve: [], currentIndex: 0,
    correctCount: 0, points: 0, streak: 0, timer: null, timeLeft: TIME_PER_QUESTION, answered: false,
    lifelines: { fifty: 1, skip: 1 }, fiftyUsedOnCurrent: false, doubled: false,
  };
  let currentScreen = 'home';

  // ---------- Utils ----------
  function showScreen(name){
    currentScreen = name;
    els.screenHome.classList.toggle('active', name === 'home');
    els.screenQuiz.classList.toggle('active', name === 'quiz');
    els.screenResult.classList.toggle('active', name === 'result');
    window.scrollTo(0,0);
    if(name === 'quiz') Ads.hideBanner(); else Ads.showBanner();
  }
  let toastTimer = null;
  function toast(msg){
    els.toast.textContent = msg;
    els.toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => els.toast.classList.remove('show'), 2200);
  }
  function shuffle(arr){
    const a = arr.slice();
    for(let i=a.length-1;i>0;i--){ const j = Math.floor(Math.random()*(i+1)); [a[i],a[j]] = [a[j],a[i]]; }
    return a;
  }

  // ---------- Storage ----------
  function lsGet(k, d){ try{ const v = localStorage.getItem(k); return v === null ? d : v; }catch(e){ return d; } }
  function lsSet(k, v){ try{ localStorage.setItem(k, String(v)); }catch(e){} }
  const getBest = (id) => parseInt(lsGet('tahaddi_best_' + id, '0'), 10);
  const getStars = (id) => parseInt(lsGet('tahaddi_stars_' + id, '0'), 10);
  function saveResult(id, points, stars){
    let isNewBest = false;
    if(points > getBest(id)){ lsSet('tahaddi_best_' + id, points); isNewBest = true; }
    if(stars > getStars(id)) lsSet('tahaddi_stars_' + id, stars);
    return isNewBest;
  }
  function getOverallBest(){
    let best = getBest('random');
    CATEGORIES.forEach(c => { best = Math.max(best, getBest(c.id)); });
    return best;
  }
  const getPlayedCount = () => parseInt(lsGet('tahaddi_played', '0'), 10);
  const incPlayedCount = () => lsSet('tahaddi_played', getPlayedCount() + 1);
  function starsFor(correct, total){
    const r = correct / total;
    return r >= 0.9 ? 3 : r >= 0.7 ? 2 : r >= 0.5 ? 1 : 0;
  }
  function starsHtml(n){ return '★'.repeat(n) + '<span class="off">' + '★'.repeat(3-n) + '</span>'; }

  // ---------- Home ----------
  function renderHome(){
    els.totalBest.textContent = getOverallBest();
    els.totalPlayed.textContent = getPlayedCount();
    let totalStars = 0;
    els.catGrid.innerHTML = '';
    CATEGORIES.forEach(cat => {
      const stars = getStars(cat.id); totalStars += stars;
      const div = document.createElement('div');
      div.className = 'cat-card';
      div.style.background = cat.color;
      div.innerHTML = `<span class="emoji">${cat.icon}</span><div class="name">${cat.name}</div>
        <div class="stars">${'★'.repeat(stars)}${'☆'.repeat(3-stars)}</div>
        <div class="best">أفضل: ${getBest(cat.id)} • ${(QUESTIONS[cat.id]||[]).length} سؤال</div>`;
      div.addEventListener('click', () => { FX.tap(); startQuiz(cat.id); });
      els.catGrid.appendChild(div);
    });
    els.totalStars.textContent = totalStars + '/' + (CATEGORIES.length * 3);
  }
  els.randomPlayBtn.addEventListener('click', () => { FX.tap(); startQuiz('random'); });

  // ---------- Quiz ----------
  function prepQuestion(q){
    const shuffled = shuffle(q.options.map((opt, i) => ({ opt, isCorrect: i === q.correct })));
    return { q: q.q, explain: q.explain, options: shuffled.map(o => o.opt), correct: shuffled.findIndex(o => o.isCorrect) };
  }
  function startQuiz(catId){
    let pool = [];
    if(catId === 'random') Object.keys(QUESTIONS).forEach(k => { pool = pool.concat(QUESTIONS[k]); });
    else pool = QUESTIONS[catId] || [];
    const all = shuffle(pool);
    game.categoryId = catId;
    game.roundQuestions = all.slice(0, QUESTIONS_PER_ROUND).map(prepQuestion);
    game.reserve = all.slice(QUESTIONS_PER_ROUND);
    game.currentIndex = 0; game.correctCount = 0; game.points = 0; game.streak = 0;
    game.lifelines = { fifty: 1, skip: 1 }; game.doubled = false;
    const cat = CATEGORIES.find(c => c.id === catId);
    els.quizCatTitle.textContent = cat ? cat.name : 'لعب سريع';
    showScreen('quiz');
    renderQuestion();
  }

  function renderLifelines(){
    [['fifty', els.llFifty, els.llFiftyBadge], ['skip', els.llSkip, els.llSkipBadge]].forEach(([k, btn, badge]) => {
      const n = game.lifelines[k];
      const disabled = game.answered || (k === 'fifty' && game.fiftyUsedOnCurrent);
      btn.classList.remove('ad', 'used');
      if(n > 0){ badge.textContent = n; }
      else if(Ads.rewardedAvailable()){ badge.textContent = '📺 +1'; btn.classList.add('ad'); }
      else { badge.textContent = '0'; btn.classList.add('used'); }
      if(disabled) btn.classList.add('used');
    });
  }

  function renderQuestion(){
    game.answered = false; game.fiftyUsedOnCurrent = false;
    game.timeLeft = TIME_PER_QUESTION;
    const q = game.roundQuestions[game.currentIndex];
    els.quizProgress.textContent = `${game.currentIndex+1} / ${game.roundQuestions.length}`;
    els.quizScore.textContent = `النقاط: ${game.points}`;
    els.quizStreak.textContent = game.streak >= 2 ? `🔥 ${game.streak}` : '';
    els.questionText.textContent = q.q;
    els.explainBox.classList.remove('show'); els.explainBox.textContent = '';
    els.nextBtn.classList.remove('show');
    els.optionsList.innerHTML = '';
    const letters = ['أ','ب','ج','د'];
    q.options.forEach((opt, idx) => {
      const btn = document.createElement('button');
      btn.className = 'option-btn';
      btn.innerHTML = `<span class="letter">${letters[idx] || ''}</span><span></span>`;
      btn.lastChild.textContent = opt;
      btn.addEventListener('click', () => submitAnswer(idx));
      els.optionsList.appendChild(btn);
    });
    renderLifelines();
    startTimer();
  }

  function updateTimerUI(){
    els.timerNum.textContent = Math.max(0, game.timeLeft);
    const low = game.timeLeft <= LOW_TIME;
    els.timerNum.classList.toggle('low', low);
    els.timerBarFill.classList.toggle('low', low);
  }
  function startTimer(){
    clearInterval(game.timer);
    els.timerBarFill.style.transition = 'none';
    els.timerBarFill.style.width = '100%';
    void els.timerBarFill.offsetWidth;
    els.timerBarFill.style.transition = `width ${TIME_PER_QUESTION}s linear`;
    els.timerBarFill.style.width = '0%';
    updateTimerUI();
    game.timer = setInterval(() => {
      game.timeLeft -= 1;
      updateTimerUI();
      if(game.timeLeft > 0 && game.timeLeft <= 3) FX.tick();
      if(game.timeLeft <= 0){ clearInterval(game.timer); if(!game.answered) submitAnswer(-1); }
    }, 1000);
  }
  function pauseTimer(){
    clearInterval(game.timer);
    const w = getComputedStyle(els.timerBarFill).width;
    els.timerBarFill.style.transition = 'none';
    els.timerBarFill.style.width = w;
  }
  function resumeTimer(){
    if(game.answered || currentScreen !== 'quiz') return;
    const pct = (game.timeLeft / TIME_PER_QUESTION) * 100;
    els.timerBarFill.style.transition = 'none';
    els.timerBarFill.style.width = pct + '%';
    void els.timerBarFill.offsetWidth;
    els.timerBarFill.style.transition = `width ${game.timeLeft}s linear`;
    els.timerBarFill.style.width = '0%';
    game.timer = setInterval(() => {
      game.timeLeft -= 1; updateTimerUI();
      if(game.timeLeft > 0 && game.timeLeft <= 3) FX.tick();
      if(game.timeLeft <= 0){ clearInterval(game.timer); if(!game.answered) submitAnswer(-1); }
    }, 1000);
  }

  function submitAnswer(selectedIdx){
    if(game.answered) return;
    game.answered = true;
    clearInterval(game.timer);
    els.timerBarFill.style.transition = 'none';
    const q = game.roundQuestions[game.currentIndex];
    els.optionsList.querySelectorAll('.option-btn').forEach((btn, idx) => {
      btn.classList.add('disabled');
      if(idx === q.correct){ btn.classList.add('correct'); btn.classList.remove('removed'); }
      else if(idx === selectedIdx) btn.classList.add('wrong');
    });
    if(selectedIdx === q.correct){
      game.correctCount++; game.streak++;
      let gained = 10 + Math.max(0, game.timeLeft - 5);          // مكافأة السرعة
      if(game.streak % 3 === 0) gained += 5;                      // مكافأة التتابع
      game.points += gained;
      FX.correct();
      toast(`+${gained} نقطة`);
    } else {
      game.streak = 0;
      FX.wrong();
      if(selectedIdx === -1) toast('⏰ انتهى الوقت');
    }
    els.quizScore.textContent = `النقاط: ${game.points}`;
    els.quizStreak.textContent = game.streak >= 2 ? `🔥 ${game.streak}` : '';
    if(q.explain){ els.explainBox.textContent = `💡 ${q.explain}`; els.explainBox.classList.add('show'); }
    els.nextBtn.classList.add('show');
    els.nextBtn.textContent = (game.currentIndex+1 < game.roundQuestions.length) ? 'السؤال التالي ›' : 'عرض النتيجة';
    renderLifelines();
  }

  els.nextBtn.addEventListener('click', () => {
    FX.tap();
    game.currentIndex++;
    if(game.currentIndex >= game.roundQuestions.length) finishRound();
    else renderQuestion();
  });

  // ---------- Lifelines ----------
  async function useLifeline(kind){
    if(game.answered) return;
    if(kind === 'fifty' && game.fiftyUsedOnCurrent) return;
    if(game.lifelines[kind] <= 0){
      if(!Ads.rewardedAvailable()){ toast('ما بقاتش وسائل مساعدة فـ هاد الجولة'); return; }
      pauseTimer();
      const ok = await Ads.showRewarded();
      if(!ok){ toast('خاصك تكمل الإعلان باش تاخذ المكافأة'); resumeTimer(); renderLifelines(); return; }
      game.lifelines[kind]++;
      resumeTimer();
    }
    game.lifelines[kind]--;
    FX.lifeline();
    if(kind === 'fifty'){
      game.fiftyUsedOnCurrent = true;
      const q = game.roundQuestions[game.currentIndex];
      const wrong = shuffle(q.options.map((_, i) => i).filter(i => i !== q.correct)).slice(0, 2);
      const btns = els.optionsList.querySelectorAll('.option-btn');
      wrong.forEach(i => btns[i] && btns[i].classList.add('removed'));
      renderLifelines();
    } else {
      // تخطي: بدّل السؤال بسؤال جديد بلا ما تخسر
      if(game.reserve.length){
        game.roundQuestions[game.currentIndex] = prepQuestion(game.reserve.shift());
        renderQuestion();
      } else {
        clearInterval(game.timer);
        game.currentIndex++;
        if(game.currentIndex >= game.roundQuestions.length) finishRound(); else renderQuestion();
      }
    }
  }
  els.llFifty.addEventListener('click', () => useLifeline('fifty'));
  els.llSkip.addEventListener('click', () => useLifeline('skip'));

  function exitQuiz(){ clearInterval(game.timer); showScreen('home'); renderHome(); }
  els.quizBackBtn.addEventListener('click', () => { FX.tap(); exitQuiz(); });

  // ---------- Result ----------
  function finishRound(){
    incPlayedCount();
    const total = game.roundQuestions.length;
    const stars = starsFor(game.correctCount, total);
    const isNewBest = saveResult(game.categoryId, game.points, stars);
    if(stars === 3){ els.resultEmoji.textContent = '🏆'; els.resultTitle.textContent = 'ممتاز! ما شاء الله'; }
    else if(stars === 2){ els.resultEmoji.textContent = '🌟'; els.resultTitle.textContent = 'أحسنت!'; }
    else if(stars === 1){ els.resultEmoji.textContent = '👏'; els.resultTitle.textContent = 'جيد، واصل!'; }
    else { els.resultEmoji.textContent = '📚'; els.resultTitle.textContent = 'حاول مرة أخرى'; }
    els.resultStars.innerHTML = starsHtml(stars);
    els.resultScore.textContent = game.correctCount;
    els.resultTotal.textContent = total;
    els.resultPoints.textContent = game.points;
    els.newBest.classList.toggle('show', isNewBest && game.points > 0);
    els.doubleBtn.classList.toggle('show', game.points > 0 && Ads.rewardedAvailable());
    showScreen('result');
    if(stars >= 2) FX.win();
  }

  els.doubleBtn.addEventListener('click', async () => {
    if(game.doubled) return;
    const ok = await Ads.showRewarded();
    if(!ok){ toast('خاصك تكمل الإعلان باش تاخذ المكافأة'); return; }
    game.doubled = true;
    game.points *= 2;
    els.resultPoints.textContent = game.points;
    const isNewBest = saveResult(game.categoryId, game.points, 0);
    if(isNewBest) els.newBest.classList.add('show');
    els.doubleBtn.classList.remove('show');
    FX.win(); toast('🎉 تضاعفت نقاطك!');
  });

  els.playAgainBtn.addEventListener('click', async () => { FX.tap(); await Ads.maybeInterstitial(); startQuiz(game.categoryId); });
  els.backHomeBtn.addEventListener('click', async () => { FX.tap(); await Ads.maybeInterstitial(); showScreen('home'); renderHome(); });

  // ---------- Settings ----------
  function syncSwitches(){
    els.swSound.classList.toggle('on', FX.settings.sound);
    els.swVibrate.classList.toggle('on', FX.settings.vibrate);
    els.rowPrivacy.style.display = Ads.privacyRequired ? '' : 'none';
  }
  function openSheet(){ syncSwitches(); els.sheet.classList.add('show'); els.sheetBg.classList.add('show'); }
  function closeSheet(){ els.sheet.classList.remove('show'); els.sheetBg.classList.remove('show'); }
  const sheetOpen = () => els.sheet.classList.contains('show');
  els.settingsBtn.addEventListener('click', () => { FX.tap(); openSheet(); });
  els.sheetBg.addEventListener('click', closeSheet);
  els.swSound.addEventListener('click', () => { FX.settings.sound = !FX.settings.sound; syncSwitches(); FX.tap(); });
  els.swVibrate.addEventListener('click', () => { FX.settings.vibrate = !FX.settings.vibrate; syncSwitches(); FX.tap(); });
  els.privacyOptionsBtn.addEventListener('click', () => Ads.showPrivacyOptions());
  let resetArmed = false;
  els.resetBtn.addEventListener('click', () => {
    if(!resetArmed){ resetArmed = true; toast('اضغط مرة أخرى للتأكيد'); setTimeout(() => resetArmed = false, 3000); return; }
    resetArmed = false;
    try{ Object.keys(localStorage).filter(k => /^tahaddi_(best|stars|played)/.test(k)).forEach(k => localStorage.removeItem(k)); }catch(e){}
    renderHome(); closeSheet(); toast('تم مسح النتائج');
  });

  // ---------- Native integration ----------
  const N = window.Native;
  if(N && N.isNative){
    try{ N.StatusBar.setStyle({ style: N.Style.Dark }); N.StatusBar.setBackgroundColor({ color: '#241938' }); }catch(e){}
    try{
      N.App.addListener('backButton', () => {
        if(sheetOpen()) closeSheet();
        else if(currentScreen === 'quiz') exitQuiz();
        else if(currentScreen === 'result'){ showScreen('home'); renderHome(); }
        else N.App.exitApp();
      });
      N.App.addListener('pause', () => { if(currentScreen === 'quiz' && !game.answered) pauseTimer(); });
      N.App.addListener('resume', () => { if(currentScreen === 'quiz' && !game.answered) resumeTimer(); });
    }catch(e){}
  }
  document.addEventListener('ads-ready', () => { if(currentScreen === 'quiz') renderLifelines(); syncSwitches(); });

  // ---------- Init ----------
  renderHome();
  Ads.init().finally(() => {
    if(currentScreen !== 'quiz') Ads.showBanner();
    try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){}
  });
})();
