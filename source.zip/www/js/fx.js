// أصوات (مولّدة بـ Web Audio، بلا ملفات) + اهتزاز
(function(){
  'use strict';
  let ctx = null;
  function ac(){
    if(!ctx){
      const C = window.AudioContext || window.webkitAudioContext;
      if(!C) return null;
      ctx = new C();
    }
    if(ctx.state === 'suspended') ctx.resume();
    return ctx;
  }
  function tone(freq, start, dur, type, vol){
    const a = ac(); if(!a) return;
    const o = a.createOscillator(), g = a.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(freq, a.currentTime + start);
    g.gain.setValueAtTime(0.0001, a.currentTime + start);
    g.gain.exponentialRampToValueAtTime(vol || 0.18, a.currentTime + start + 0.015);
    g.gain.exponentialRampToValueAtTime(0.0001, a.currentTime + start + dur);
    o.connect(g); g.connect(a.destination);
    o.start(a.currentTime + start); o.stop(a.currentTime + start + dur + 0.02);
  }

  const settings = {
    get sound(){ try{ return localStorage.getItem('tahaddi_sound') !== '0'; }catch(e){ return true; } },
    set sound(v){ try{ localStorage.setItem('tahaddi_sound', v ? '1' : '0'); }catch(e){} },
    get vibrate(){ try{ return localStorage.getItem('tahaddi_vibrate') !== '0'; }catch(e){ return true; } },
    set vibrate(v){ try{ localStorage.setItem('tahaddi_vibrate', v ? '1' : '0'); }catch(e){} },
  };

  function haptic(kind){
    if(!settings.vibrate) return;
    const N = window.Native;
    try{
      if(N && N.isNative){
        if(kind === 'success') N.Haptics.notification({ type: N.NotificationType.Success });
        else if(kind === 'error') N.Haptics.notification({ type: N.NotificationType.Error });
        else N.Haptics.impact({ style: N.ImpactStyle.Light });
      } else if(navigator.vibrate){
        navigator.vibrate(kind === 'error' ? [40, 60, 40] : 20);
      }
    }catch(e){}
  }

  window.FX = {
    settings,
    tap(){ if(settings.sound) tone(660, 0, 0.06, 'triangle', 0.08); haptic('tap'); },
    correct(){ if(settings.sound){ tone(784, 0, 0.12, 'sine'); tone(1047, 0.1, 0.22, 'sine'); } haptic('success'); },
    wrong(){ if(settings.sound){ tone(220, 0, 0.18, 'sawtooth', 0.09); tone(165, 0.14, 0.26, 'sawtooth', 0.09); } haptic('error'); },
    tick(){ if(settings.sound) tone(1200, 0, 0.04, 'square', 0.04); },
    win(){ if(settings.sound){ [523,659,784,1047].forEach((f,i)=>tone(f, i*0.11, 0.25, 'triangle', 0.14)); } haptic('success'); },
    lifeline(){ if(settings.sound){ tone(880, 0, 0.08, 'sine', 0.1); tone(1320, 0.07, 0.12, 'sine', 0.1); } haptic('tap'); },
  };
})();
