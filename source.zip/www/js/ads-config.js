// إعدادات AdMob — بدّل هاد القيم بالـIDs الحقيقية من حساب AdMob.
// ما دام TEST_MODE = true، كتبان إعلانات تجريبية ديال Google (آمنة للتجربة).
window.ADS_CONFIG = {
  TEST_MODE: false,
  BANNER_ID: 'ca-app-pub-2986107222837015/8964803919',
  INTERSTITIAL_ID: 'ca-app-pub-2986107222837015/2535126934',
  REWARDED_ID: 'ca-app-pub-2986107222837015/6329978274',
  INTERSTITIAL_EVERY_N_ROUNDS: 2,
};
