// إعدادات AdMob — بدّل هاد القيم بالـIDs الحقيقية من حساب AdMob.
// ما دام TEST_MODE = true، كتبان إعلانات تجريبية ديال Google (آمنة للتجربة).
window.ADS_CONFIG = {
  TEST_MODE: true,
  BANNER_ID: 'ca-app-pub-3940256099942544/9214589741',        // test adaptive banner
  INTERSTITIAL_ID: 'ca-app-pub-3940256099942544/1033173712',  // test interstitial
  REWARDED_ID: 'ca-app-pub-3940256099942544/5224354917',      // test rewarded
  INTERSTITIAL_EVERY_N_ROUNDS: 2,
};
