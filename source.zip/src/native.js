import { Capacitor } from '@capacitor/core';
import { AdMob, BannerAdPluginEvents, RewardAdPluginEvents, InterstitialAdPluginEvents, BannerAdSize, BannerAdPosition } from '@capacitor-community/admob';
import { Haptics, ImpactStyle, NotificationType } from '@capacitor/haptics';
import { StatusBar, Style } from '@capacitor/status-bar';
import { SplashScreen } from '@capacitor/splash-screen';
import { App } from '@capacitor/app';

window.Native = {
  isNative: Capacitor.isNativePlatform(),
  AdMob, BannerAdPluginEvents, RewardAdPluginEvents, InterstitialAdPluginEvents, BannerAdSize, BannerAdPosition,
  Haptics, ImpactStyle, NotificationType, StatusBar, Style, SplashScreen, App,
};
